class BlockControler{

  construtor(){
    this._name = 'input'
    this._id = '1'
  }
}
